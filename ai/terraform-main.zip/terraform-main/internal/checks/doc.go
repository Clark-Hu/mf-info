// Copyright IBM Corp. 2014, 2026
// SPDX-License-Identifier: BUSL-1.1

// Package checks contains the models for representing various kinds of
// declarative condition checks that can be defined in a Terraform module
// and then evaluated and reported by Terraform Core during plan and apply
// operations.
package checks
