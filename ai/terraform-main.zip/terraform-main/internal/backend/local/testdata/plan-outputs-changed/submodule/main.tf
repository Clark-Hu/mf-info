output "foo" {
  value = "bar"
}
