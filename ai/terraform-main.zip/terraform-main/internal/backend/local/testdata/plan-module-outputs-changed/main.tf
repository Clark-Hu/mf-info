module "mod" {
  source = "./mod"
}
