run "just_go" {}
